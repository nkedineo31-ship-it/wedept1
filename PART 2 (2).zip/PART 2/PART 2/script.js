
window.addEventListener("load", function () {
    const loader = document.querySelector(".loader");

    if (loader) {
        setTimeout(() => {
            loader.style.display = "none";
        }, 1500);
    }
});

// Welcome Message
window.addEventListener("DOMContentLoaded", function () {
    alert("Welcome to SPORTSCENE TFG Website!");
});

// Scroll To Top Function
function topFunction() {
    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });
}

// Show Top Button Only When Scrolling
window.onscroll = function () {
    const topBtn = document.getElementById("topBtn");

    if (topBtn) {
        if (
            document.body.scrollTop > 100 ||
            document.documentElement.scrollTop > 100
        ) {
            topBtn.style.display = "block";
        } else {
            topBtn.style.display = "none";
        }
    }
};

// Service Card Hover Effect
const cards = document.querySelectorAll(".service-card");

cards.forEach(card => {
    card.addEventListener("mouseover", () => {
        card.style.transform = "scale(1.03)";
    });

    card.addEventListener("mouseout", () => {
        card.style.transform = "scale(1)";
    });
});

// Tab Function
function openCity(evt, cityName) {

    let i, tabcontent, tablinks;

    tabcontent = document.getElementsByClassName("tabcontent");

    for (i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    tablinks = document.getElementsByClassName("tablinks");

    for (i = 0; i < tablinks.length; i++) {
        tablinks[i].className =
            tablinks[i].className.replace(" active", "");
    }

    document.getElementById(cityName).style.display = "block";

    evt.currentTarget.className += " active";
}

// Open First Tab Automatically
document.addEventListener("DOMContentLoaded", function () {
    const firstTab = document.querySelector(".tablinks");

    if (firstTab) {
        firstTab.click();
    }
});

// Image Click Zoom
const images = document.querySelectorAll("img");

images.forEach(img => {
    img.addEventListener("click", () => {

        if (img.style.transform === "scale(1.4)") {
            img.style.transform = "scale(1)";
        } else {
            img.style.transform = "scale(1.4)";
        }
    });
});

// Footer Year Auto Update
const footer = document.querySelector("footer p");

if (footer) {
    footer.innerHTML =
        "&copy; " +
        new Date().getFullYear() +
        " SPORTSCENE TFG WEBSITE";
}
// Loader
window.addEventListener("load", function () {

    const loader = document.querySelector(".loader");

    if(loader){
        setTimeout(function(){
            loader.style.display = "none";
        },1000);
    }
});

// Tabs
function openCity(evt, cityName) {

    let tabcontent;
    let tablinks;

    tabcontent = document.getElementsByClassName("tabcontent");

    for(let i = 0; i < tabcontent.length; i++) {
        tabcontent[i].style.display = "none";
    }

    tablinks = document.getElementsByClassName("tablinks");

    for(let i = 0; i < tablinks.length; i++) {
        tablinks[i].className =
        tablinks[i].className.replace(" active", "");
    }

    document.getElementById(cityName).style.display = "block";

    evt.currentTarget.className += " active";
}

// Open first tab automatically
window.onload = function() {

    const firstTab =
    document.getElementsByClassName("tablinks")[0];

    if(firstTab){
        firstTab.click();
    }
}

// Modal
const modal = document.getElementById("myModal");

const btn = document.getElementById("openModal");

const closeBtn =
document.getElementsByClassName("close")[0];

if(btn){

    btn.onclick = function(){

        modal.style.display = "block";
    }
}

if(closeBtn){

    closeBtn.onclick = function(){

        modal.style.display = "none";
    }
}

window.onclick = function(event){

    if(event.target == modal){

        modal.style.display = "none";
    }
}


// Welcome Message
alert("Welcome to SPORTSCENE TFG Website");

const text = "Welcome to SPORTSCENE TFG";
let i = 0;

function typingEffect() {

    if (i < text.length) {

        document.getElementById("typing").innerHTML += text.charAt(i);

        i++;

        setTimeout(typingEffect, 100);
    }
}

typingEffect();

const newCard = document.createElement("div");
newCard.className = "service-card";

newCard.innerHTML = `
<h3>New Arrivals</h3>
<p>Check out the latest sneaker collections.</p>
`;

document.body.appendChild(newCard);

document.querySelector("h1").textContent =
"SPORTSCENE TFG OFFICIAL WEBSITE";

document.getElementById("darkModeBtn")
.addEventListener("click", function () {

    document.body.classList.toggle("dark-mode");
});

const greeting =
document.getElementById("greeting");

const hour = new Date().getHours();

if(hour < 12){
    greeting.textContent = "Good Morning!";
}
else if(hour < 18){
    greeting.textContent = "Good Afternoon!";
}
else{
    greeting.textContent = "Good Evening!";
}

const message =
document.getElementById("message");

const count =
document.getElementById("count");

message.addEventListener("input", function(){

    count.textContent =
    this.value.length + " Characters";
});

setInterval(() => {

    document.getElementById("dateTime")
    .textContent =
    new Date().toLocaleString();

},1000);